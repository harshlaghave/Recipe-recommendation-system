import csv

# Define the data for the 7-day workout challenge
challenge_data = [
    {  # Day 1
        'gender': 'male',
        'day': 1,
        'tasks': ["Squats: 4 sets, 8-10 reps", "Push-ups: 3 sets, 10-12 reps"],
        'diet_plan': ["Breakfast: Scrambled eggs with spinach and whole-grain toast, Greek yogurt with honey and mixed berries."],
    },
    {  # Day 2
        'gender': 'male',
        'day': 2,
        'tasks': ["Lunges: 3 sets, 12 reps each leg", "Jumping jacks: 3 sets, 30 seconds each"],
        'diet_plan': ["Breakfast: Greek yogurt with sliced strawberries and granola."],
    },
    # Add data for more days as needed
    {  # Day 1
        'gender': 'female',
        'day': 1,
        'tasks': ["Squats: 4 sets, 8-10 reps", "Push-ups: 3 sets, 10-12 reps"],
        'diet_plan': ["Breakfast: Scrambled eggs with spinach and whole-grain toast, Greek yogurt with honey and mixed berries."],
    },
    {  # Day 2
        'gender': 'female',
        'day': 2,
        'tasks': ["Lunges: 3 sets, 12 reps each leg", "Jumping jacks: 3 sets, 30 seconds each"],
        'diet_plan': ["Breakfast: Greek yogurt with sliced strawberries and granola."],
    },
    # Add data for more days as needed
]

# Define the CSV file name
csv_file = 'workout_challenge.csv'

# Define the CSV fieldnames
fieldnames = ['Gender', 'Day', 'Tasks', 'Diet Plan']

# Write the data to the CSV file
with open(csv_file, mode='w', newline='') as file:
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    
    # Write the header row
    writer.writeheader()
    
    # Write data for each day
    for entry in challenge_data:
        writer.writerow({
            'Gender': entry['gender'],
            'Day': entry['day'],
            'Tasks': ', '.join(entry['tasks']),
            'Diet Plan': ', '.join(entry['diet_plan'])
        })

print(f"CSV file '{csv_file}' has been created successfully.")
