# User information input
user_name = input("Enter your name: ")
age = int(input("Enter your age: "))
email = input("Enter your email address: ")
weight_kg = float(input("Enter your current weight in kilograms: "))
height_cm = float(input("Enter your height in centimeters: "))
gender = input("Enter Your Gender (male/female): ").lower()

# BMI calculation
bmi = weight_kg / ((height_cm / 100) ** 2)

# BMI interpretation
if bmi <= 18.5:
    interpretation = "You are underweight. Consult a healthcare professional for personalized guidance."
elif 18.5 < bmi < 25:
    interpretation = "You are in the normal weight range."
elif 25 <= bmi < 30:
    interpretation = "You are overweight. Consider incorporating healthy lifestyle changes like increased physical activity and dietary adjustments."
else:
    interpretation = "You are obese. Consult a healthcare professional for a personalized plan to manage your weight and improve your health."

# Present BMI results
print(f"\nHi {user_name},")
print(f"According to your Body Mass Index (BMI), calculated as {bmi:.2f},")
print(interpretation)

# Disclaimer
print("\n**Disclaimer:** This program's results should not be interpreted as medical advice. Always consult with a healthcare professional for personalized guidance regarding your health and fitness goals.")

# Choice for challenge enrollment
print("\nWelcome to our app.")
print("Which challenge would you like to enroll in?")
print("1. 7-Day Fitness Challenge")
print("2. 30-Day Fitness Challenge")
choice = int(input("Enter the number of your choice: "))

# Challenge details
if choice == 1:
    challenge_days = 7
    challenge_name = '7-Day Fitness Challenge'
elif choice == 2:
    challenge_days = 30
    challenge_name = '30-Day Fitness Challenge'
else:
    print("Invalid choice. Exiting...")
    exit()

# Define tasks and diet plans for each day based on gender
if gender == "male":
    challenge_days_data = [
        {  # Day 1
            'tasks': [
                "- Squats: 4 sets, 8-10 reps",
                "- Push-ups: 3 sets, 10-12 reps",
                # Add more exercises as needed
            ],
            'diet_plan': [
                "- Breakfast: Scrambled eggs with spinach and whole-grain toast, Greek yogurt with honey and mixed berries.",
                "- Lunch: Grilled chicken breast with quinoa and steamed vegetables.",
                # Add more meals and snacks as needed
            ]
        },
        {  # Day 2
            'tasks': [
                "- Lunges: 3 sets, 12 reps each leg",
                "- Jumping jacks: 3 sets, 30 seconds each",
                # Add more exercises as needed
            ],
            'diet_plan': [
                "- Breakfast: Greek yogurt with sliced strawberries and granola.",
                "- Lunch: Mixed green salad with grilled salmon and avocado.",
                # Add more meals and snacks as needed
            ]
        },
        # Add more days as needed
    ]
elif gender == "female":
    challenge_days_data = [
        {  # Day 1
            'tasks': [
                "- Squats: 4 sets, 8-10 reps",
                "- Push-ups: 3 sets, 10-12 reps",
                # Add more exercises as needed
            ],
            'diet_plan': [
                "- Breakfast: Scrambled eggs with spinach and whole-grain toast, Greek yogurt with honey and mixed berries.",
                "- Lunch: Grilled chicken breast with quinoa and steamed vegetables.",
                # Add more meals and snacks as needed
            ]
        },
        {  # Day 2
            'tasks': [
                "- Lunges: 3 sets, 12 reps each leg",
                "- Jumping jacks: 3 sets, 30 seconds each",
                # Add more exercises as needed
            ],
            'diet_plan': [
                "- Breakfast: Greek yogurt with sliced strawberries and granola.",
                "- Lunch: Mixed green salad with grilled salmon and avocado.",
                # Add more meals and snacks as needed
            ]
        },
        # Add more days as needed
    ]
else:
    print("Invalid gender choice. Exiting...")
    exit()

# Define common tasks and diet plans for each day
common_days_data = [
    {  # Day 1
        'tasks': [
            "- Plank: 3 sets, hold for 1 minute each",
            "- Burpees: 3 sets, 8 reps",
            # Add more exercises as needed
        ],
        'diet_plan': [
            "- Breakfast: Smoothie with spinach, banana, almond milk, and protein powder.",
            "- Lunch: Grilled chicken salad with mixed vegetables.",
            # Add more meals and snacks as needed
        ]
    },
    # Add more common days as needed
]

# Function to display challenge details
def display_challenge_details(challenge_days, challenge_name, challenge_days_data):
    for day in range(challenge_days):
        print(f"\nDay {day + 1} Tasks for the {challenge_name}:")
        for task in challenge_days_data[day]['tasks']:
            print(task)
        print(f"\nDiet plan for Day {day + 1} of the {challenge_name}:")
        for meal in challenge_days_data[day]['diet_plan']:
            print(meal)

# Display challenge details based on gender
if gender == "male" or gender == "female":
    display_challenge_details(challenge_days, challenge_name, challenge_days_data)
else:
    # If gender is not specified, display common challenge details
    display_challenge_details(challenge_days, challenge_name, common_days_data)
