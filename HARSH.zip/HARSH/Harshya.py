import pandas as pd

# Load dataset
recipes_data = pd.read_csv('recipes.csv')

# Function to filter recipes based on user preferences
def recommend_recipes(ingredients, diet, cuisine):
    recommended_recipes = []
    for index, row in recipes_data.iterrows():
        # Check if ingredients match
        recipe_ingredients = str(row['ingredients']).lower()
        if all(ingredient.lower() in recipe_ingredients for ingredient in ingredients):
            # Check if diet restriction matches
            if diet.lower() in str(row['diet']).lower() or diet.lower() == 'none':
                # Check if cuisine matches
                if cuisine.lower() in str(row['cuisine']).lower() or cuisine.lower() == 'none':
                    recommended_recipes.append({'title': row['recipe_title'], 'url': row['url']})
    return recommended_recipes

# Function to prompt user to input new recipe
def add_new_recipe():
    recipe_title = input("Enter the title of the new recipe: ")
    ingredients = input("Enter the ingredients (comma-separated): ")
    diet = input("Enter the diet restriction (e.g., vegan, vegetarian, none): ")
    cuisine = input("Enter the cuisine (e.g., Italian, Mexican, none): ")
    url = input("Enter the URL of the recipe (leave blank if none): ")
    new_recipe = {'recipe_title': recipe_title, 'ingredients': ingredients, 'diet': diet, 'cuisine': cuisine}
    recipes_data = recipes_data.append(new_recipe, ignore_index=True)
    recipes_data.to_csv('recipes.csv', index=False)
    print("New recipe added successfully!")

# Take user input
user_ingredients = input("Enter ingredients: ").split(',')
user_diet = input("Enter diet restriction (e.g., vegan, vegetarian, none): ")
user_cuisine = input("Enter preferred cuisine (e.g., Italian, Mexican, none): ")

# Get recommended recipes
recommended_recipes = recommend_recipes(user_ingredients, user_diet, user_cuisine)

# Display recommendations
if recommended_recipes:
    print("Recommended recipes:")
    for recipe in recommended_recipes:
        print(f"{recipe['title']}: {recipe['url']}")
else:
    print("No recipes found matching your preferences.")
    add_recipe_choice = input("Would you like to add a new recipe? (y/n): ").lower()
    if add_recipe_choice == 'y':
        add_new_recipe()
    else:
        print("Okay, THANK YOU.")
